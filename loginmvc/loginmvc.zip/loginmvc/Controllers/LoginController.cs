﻿using loginmvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using MySql.Data.MySqlClient;

namespace loginmvc.Controllers
{
    public class LoginController : Controller
    {
        
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Authorise(User userModel, string button)
        {
            if (button == "login")
            {
                string connstr = WebConfigurationManager.ConnectionStrings["MySqlConnection"].ConnectionString;
                MySqlConnection con = new MySqlConnection(connstr);
                bool auth = false;
                con.Open();
                string query = @"SELECT * FROM user WHERE Email='" + userModel.Email + "' AND " + "Password='" + userModel.Password + "'";
                MySqlCommand cmd = new MySqlCommand(query, con);
                MySqlDataReader dr = cmd.ExecuteReader();
                
                if (dr.Read())
                {
                   
                    auth = true;
                }
                else
                {
                    auth = false;
                }
                if (auth == true)
                {
                    Response.Write("<script>alert('logged in successfully')</script>");
                    Console.Write("===========loged in=================");
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    return View("Index", userModel);
                }
               
            }
            else
            {
                return RedirectToAction("Index", "Register");
            }
            
        }
       
    }
}